const express = require('express');
const router = express.Router();

const {
  partOfSpeech,
  findWord,
  findWordAndPos,
} = require('../controllers/wordAndPos');

// get
router.get('/:word', findWord);
router.get('/part-of-speech/:part', partOfSpeech);
router.get('/:word/:partOfSpeech', findWordAndPos);

module.exports.wordRouter = router;
