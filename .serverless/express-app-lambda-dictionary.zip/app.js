const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');
require('dotenv').config();
const app = express();

// router
const { wordRouter } = require('./routers/word');

// middle-ware
// app.use(express.json());
app.use(cors());

app.get('/', function (req, res) {
  res.send('Hello World!');
});
app.use('/', wordRouter);

module.exports.handler = serverless(app);
