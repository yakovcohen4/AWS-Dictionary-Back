// require('dotenv').config();
// const AWS = require('aws-sdk');

// console.log(process.env.ACCESS_KEY_ID);

// const dynamoDB = new AWS.DynamoDB.DocumentClient({
//   region: 'eu-west-1',
//   accessKeyId: process.env.Access_key_ID,
//   secretAccessKey: process.env.Secret_access_key,
// });

// const data = require('./dictionary.json');

// const insertToDb = async event => {
//   try {
//     for (const word of event) {
//       const params = {
//         TableName: 'dictionary',
//         Item: word,
//       };

//       dynamoDB.put(params, (err, result) => {
//         if (err) {
//           console.log(err);
//         } else {
//           console.log(`Insert ${word.word}`);
//         }
//       });
//     }
//     return 'success';
//   } catch (err) {
//     console.log(err);
//     return err;
//   }
// };

// insertToDb(data);
// const serverless = require('serverless-http');
// const express = require('express');
// const app = express();

// app.get('/', function (req, res) {
//   res.send('Hello World!');
// });

// module.exports.handler = serverless(app);
